import { useState, useEffect, useRef } from "react";

// ── Styles as a style tag injected once ──────────────────────────────────────
const globalCSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --black: #111111;
    --white: #ffffff;
    --pink: #e8506a;
    --purple: #7c4dff;
    --mint: #d4ede1;
    --soft: #f7f5f2;
    --muted: #6b6b6b;
    --border: #e8e4df;
  }
  html { scroll-behavior: smooth; }
  body { font-family: 'DM Sans', sans-serif; color: var(--black); background: var(--white); overflow-x: hidden; margin: 0; }

  /* Navbar */
  .nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    display: flex; align-items: center; justify-content: space-between;
    padding: 1.2rem 5%;
    background: rgba(255,255,255,0.93);
    backdrop-filter: blur(14px);
    border-bottom: 1px solid var(--border);
    transition: box-shadow 0.3s;
  }
  .nav.scrolled { box-shadow: 0 2px 24px rgba(0,0,0,0.08); }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 1.4rem; font-weight: 700; color: var(--black); text-decoration: none; letter-spacing: -0.02em; }
  .nav-links { display: flex; gap: 2.5rem; list-style: none; }
  .nav-links a { font-size: 0.875rem; font-weight: 500; color: var(--muted); text-decoration: none; transition: color 0.2s; }
  .nav-links a:hover { color: var(--black); }
  .nav-cta { background: var(--black); color: white; padding: 0.6rem 1.5rem; border-radius: 50px; font-size: 0.875rem; font-weight: 500; text-decoration: none; transition: background 0.2s, transform 0.15s; }
  .nav-cta:hover { background: #333; transform: translateY(-1px); }
  .hamburger { display: none; flex-direction: column; gap: 5px; cursor: pointer; background: none; border: none; padding: 4px; }
  .hamburger span { display: block; width: 24px; height: 2px; background: var(--black); border-radius: 2px; }

  /* Hero */
  .hero {
    min-height: 100vh; padding: 120px 5% 80px;
    display: flex; flex-direction: column; align-items: center; text-align: center;
    position: relative; overflow: hidden;
  }
  .hero::before { content: ''; position: absolute; top: 15%; left: -5%; width: 320px; height: 320px; border-radius: 50%; background: radial-gradient(circle, rgba(232,80,106,0.12) 0%, transparent 70%); pointer-events: none; }
  .hero::after  { content: ''; position: absolute; bottom: 10%; right: -5%; width: 280px; height: 280px; border-radius: 50%; background: radial-gradient(circle, rgba(124,77,255,0.10) 0%, transparent 70%); pointer-events: none; }

  .hero-tag { display: inline-flex; align-items: center; gap: 0.5rem; background: #fef0f2; color: var(--pink); padding: 0.4rem 1rem; border-radius: 50px; font-size: 0.8rem; font-weight: 600; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 1.8rem; animation: fadeUp 0.6s ease both; }
  .hero-h1 { font-family: 'Playfair Display', serif; font-size: clamp(2.4rem, 6vw, 4.5rem); font-weight: 700; line-height: 1.15; max-width: 780px; margin-bottom: 1.5rem; animation: fadeUp 0.7s 0.1s ease both; }
  .pink { color: var(--pink); font-style: italic; }
  .purple { color: var(--purple); }
  .udash { text-decoration: underline; text-decoration-color: var(--pink); text-underline-offset: 6px; }
  .hero-sub { font-size: 1rem; color: var(--muted); max-width: 520px; line-height: 1.7; margin-bottom: 2.5rem; animation: fadeUp 0.7s 0.2s ease both; }
  .avatars { display: flex; align-items: center; justify-content: center; margin-bottom: 3rem; animation: fadeUp 0.7s 0.3s ease both; }
  .av { width: 52px; height: 52px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 0.75rem; margin-left: -12px; transition: transform 0.2s; flex-shrink: 0; cursor: pointer; }
  .av:first-child { margin-left: 0; }
  .av:hover { transform: translateY(-5px) scale(1.1); z-index: 2; }
  .av-stats { font-size: 0.8rem; color: var(--muted); margin-left: 1rem; text-align: left; }
  .av-stats strong { display: block; font-size: 0.95rem; color: var(--black); }
  .shape-purple { position: absolute; top: 18%; right: 12%; width: 44px; height: 52px; background: var(--purple); clip-path: polygon(50% 0%, 100% 35%, 80% 100%, 20% 100%, 0% 35%); opacity: 0.85; }
  .shape-circle { position: absolute; top: 35%; left: 8%; width: 60px; height: 60px; border: 2px solid rgba(232,80,106,0.4); border-radius: 50%; }

  /* Sections */
  section { padding: 90px 5%; }
  .sec-label { font-size: 0.75rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: var(--pink); margin-bottom: 0.8rem; }
  .reveal { opacity: 0; transform: translateY(30px); transition: opacity 0.7s ease, transform 0.7s ease; }
  .reveal.vis { opacity: 1; transform: translateY(0); }

  /* About */
  .about { background: var(--soft); display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; }
  .about-h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.8rem); line-height: 1.25; margin-bottom: 1.4rem; }
  .about-p { color: var(--muted); line-height: 1.75; margin-bottom: 1.2rem; font-size: 0.95rem; }
  .readmore { display: inline-flex; align-items: center; gap: 0.5rem; color: var(--black); font-weight: 600; font-size: 0.875rem; text-decoration: none; border-bottom: 2px solid var(--black); padding-bottom: 2px; transition: gap 0.2s, color 0.2s, border-color 0.2s; }
  .readmore:hover { gap: 0.8rem; color: var(--pink); border-color: var(--pink); }
  .img-wrap { position: relative; }
  .img-circle { width: 100%; max-width: 380px; aspect-ratio: 1; border-radius: 50%; overflow: hidden; margin: 0 auto; border: 6px solid white; box-shadow: 0 20px 60px rgba(0,0,0,0.12); }
  .photo-bg { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 3rem; }
  .pb1 { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
  .pb2 { background: linear-gradient(135deg, #f093fb 0%, #f5576c 50%, #4facfe 100%); }
  .badge { position: absolute; bottom: 15%; right: 5%; background: white; padding: 0.8rem 1.2rem; border-radius: 12px; box-shadow: 0 8px 30px rgba(0,0,0,0.12); font-size: 0.8rem; font-weight: 600; }
  .badge span { display: block; color: var(--pink); font-size: 1.4rem; font-weight: 700; }
  .tri-deco { position: absolute; bottom: 5%; left: 5%; width: 0; height: 0; border-left: 40px solid transparent; border-right: 40px solid transparent; border-bottom: 70px solid rgba(232,80,106,0.2); }

  /* Progress */
  .progress-sec { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; }
  .progress-img-wrap { position: relative; }
  .img-rect { width: 100%; border-radius: 20px; overflow: hidden; aspect-ratio: 4/3; box-shadow: 0 16px 50px rgba(0,0,0,0.13); }
  .tri-top { position: absolute; top: -20px; right: -20px; width: 0; height: 0; border-left: 55px solid transparent; border-right: 55px solid transparent; border-bottom: 95px solid rgba(232,80,106,0.85); }
  .prog-h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.8rem); line-height: 1.25; margin-bottom: 1.4rem; }
  .prog-p { color: var(--muted); line-height: 1.75; font-size: 0.95rem; margin-bottom: 1.5rem; }

  /* Services */
  .services-head { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; align-items: end; margin-bottom: 3.5rem; }
  .srv-h2 { font-family: 'Playfair Display', serif; font-size: clamp(2rem, 4vw, 3rem); line-height: 1.2; }
  .srv-intro { color: var(--muted); font-size: 0.95rem; line-height: 1.7; }
  .srv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
  .srv-left { padding-right: 4rem; border-right: 1px solid var(--border); }
  .srv-right { padding-left: 4rem; }
  .srv-cat { font-size: 0.75rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: var(--muted); margin-bottom: 1.5rem; }
  .srv-item { display: flex; align-items: center; justify-content: space-between; padding: 1.2rem 0; border-bottom: 1px solid var(--border); cursor: pointer; }
  .srv-item:last-child { border-bottom: none; }
  .srv-name { font-size: 1rem; font-weight: 500; }
  .srv-arrow { width: 32px; height: 32px; border-radius: 50%; border: 1.5px solid var(--border); display: flex; align-items: center; justify-content: center; transition: transform 0.2s, background 0.2s, border-color 0.2s; flex-shrink: 0; }
  .srv-item:hover .srv-arrow { background: var(--black); border-color: var(--black); transform: translateX(4px); }
  .srv-item:hover .arrow-svg { stroke: white; }

  /* Testimonials */
  .testi { background: var(--soft); text-align: center; }
  .testi-h2 { font-family: 'Playfair Display', serif; font-size: clamp(1.8rem, 3.5vw, 2.6rem); margin-bottom: 0.5rem; }
  .testi-sub { color: var(--muted); margin-bottom: 3.5rem; font-size: 0.95rem; }
  .testi-layout { display: grid; grid-template-columns: 160px 1fr 160px; gap: 1.5rem; align-items: center; max-width: 900px; margin: 0 auto; }
  .side-avs { display: flex; flex-direction: column; gap: 1rem; align-items: center; }
  .s-av { width: 52px; height: 52px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 0.8rem; cursor: pointer; transition: transform 0.2s; border: 3px solid white; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
  .s-av:hover { transform: scale(1.1); }
  .testi-card { background: white; border-radius: 20px; padding: 2.5rem 2rem; box-shadow: 0 8px 40px rgba(0,0,0,0.08); }
  .quote { font-size: 3rem; color: var(--mint); font-family: Georgia, serif; line-height: 1; margin-bottom: 0.5rem; }
  .testi-txt { font-size: 0.95rem; color: var(--muted); line-height: 1.75; margin-bottom: 1.5rem; }
  .testi-author { display: flex; align-items: center; gap: 0.75rem; }
  .auth-av { width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 0.8rem; }
  .auth-name { font-weight: 600; font-size: 0.9rem; }
  .auth-role { font-size: 0.78rem; color: var(--muted); }
  .dots { display: flex; gap: 0.5rem; justify-content: center; margin-top: 2rem; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--border); cursor: pointer; transition: background 0.2s, width 0.2s; border: none; padding: 0; }
  .dot.active { background: var(--pink); width: 24px; border-radius: 4px; }

  /* Newsletter */
  .newsletter { background: var(--mint); text-align: center; padding: 80px 5%; position: relative; overflow: hidden; }
  .newsletter::after { content: ''; position: absolute; top: 50%; right: 5%; transform: translateY(-50%); width: 60px; height: 72px; background: var(--purple); clip-path: polygon(50% 0%, 100% 35%, 80% 100%, 20% 100%, 0% 35%); opacity: 0.7; }
  .nl-h2 { font-family: 'Playfair Display', serif; font-size: clamp(2rem, 4vw, 3rem); margin-bottom: 0.8rem; }
  .nl-p { color: #5a7a6b; margin-bottom: 2.5rem; font-size: 0.95rem; }
  .nl-form { display: flex; max-width: 480px; margin: 0 auto; border-radius: 50px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
  .nl-input { flex: 1; padding: 1rem 1.5rem; border: none; outline: none; font-family: 'DM Sans', sans-serif; font-size: 0.9rem; }
  .nl-btn { background: var(--black); color: white; border: none; padding: 1rem 1.8rem; font-family: 'DM Sans', sans-serif; font-size: 0.875rem; font-weight: 600; cursor: pointer; transition: background 0.2s; white-space: nowrap; }
  .nl-btn:hover { background: #333; }
  .nl-btn.success { background: #2a9d5c !important; }

  /* Footer */
  footer { background: var(--black); color: white; padding: 60px 5% 30px; }
  .footer-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 3rem; margin-bottom: 3rem; }
  .fc h4 { font-size: 0.8rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: #888; margin-bottom: 1.2rem; }
  .fc .brand { font-family: 'Playfair Display', serif; font-size: 1.2rem; font-weight: 700; margin-bottom: 0.8rem; color: white; }
  .fc .brand-sub { font-size: 0.85rem; color: #888; line-height: 1.6; }
  .fc ul { list-style: none; display: flex; flex-direction: column; gap: 0.7rem; }
  .fc ul a { color: #aaa; text-decoration: none; font-size: 0.875rem; transition: color 0.2s; }
  .fc ul a:hover { color: white; }
  .fc-contact p { font-size: 0.875rem; color: #888; line-height: 1.8; }
  .fc-contact strong { color: white; }
  .footer-bottom { border-top: 1px solid #2a2a2a; padding-top: 1.5rem; display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; color: #666; }
  .footer-bottom a { color: #888; text-decoration: none; }
  .footer-bottom a:hover { color: white; }

  /* Animations */
  @keyframes fadeUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }

  /* Responsive */
  @media (max-width: 900px) {
    .about, .progress-sec { grid-template-columns: 1fr; gap: 2.5rem; }
    .progress-img-wrap { order: -1; }
    .services-head { grid-template-columns: 1fr; }
    .srv-grid { grid-template-columns: 1fr; }
    .srv-left { padding-right: 0; border-right: none; border-bottom: 1px solid var(--border); padding-bottom: 2rem; margin-bottom: 2rem; }
    .srv-right { padding-left: 0; }
    .testi-layout { grid-template-columns: 1fr; }
    .side-avs { flex-direction: row; justify-content: center; }
    .footer-grid { grid-template-columns: 1fr 1fr; gap: 2rem; }
  }
  @media (max-width: 600px) {
    .nav { padding: 1rem 4%; }
    .nav-links { display: none; }
    .hamburger { display: flex; }
    .nav-links.open { display: flex; flex-direction: column; position: fixed; top: 65px; left: 0; right: 0; background: white; padding: 1.5rem 5%; border-bottom: 1px solid var(--border); box-shadow: 0 8px 20px rgba(0,0,0,0.08); gap: 1.2rem; z-index: 99; }
    .hero { padding: 100px 5% 60px; }
    section { padding: 60px 5%; }
    .footer-grid { grid-template-columns: 1fr; }
    .nl-form { flex-direction: column; border-radius: 12px; }
    .nl-input { border-radius: 0; }
    .nl-btn { border-radius: 0 0 12px 12px; }
  }
`;

// ── Avatar colors ─────────────────────────────────────────────────────────────
const avColors = [
  "linear-gradient(135deg,#f093fb,#f5576c)",
  "linear-gradient(135deg,#4facfe,#00f2fe)",
  "linear-gradient(135deg,#43e97b,#38f9d7)",
  "linear-gradient(135deg,#fa709a,#fee140)",
  "linear-gradient(135deg,#a18cd1,#fbc2eb)",
  "linear-gradient(135deg,#ffecd2,#fcb69f)",
  "linear-gradient(135deg,#a1c4fd,#c2e9fb)",
  "linear-gradient(135deg,#fd7043,#ff8a65)",
];
const avLabels = ["AK","SR","MJ","PL","NK","TR","AS","WM"];

const ArrowIcon = () => (
  <svg className="arrow-svg" width="14" height="14" fill="none" stroke="#111" strokeWidth="2" viewBox="0 0 24 24">
    <path d="M5 12h14M12 5l7 7-7 7"/>
  </svg>
);

// ── Reveal Hook ───────────────────────────────────────────────────────────────
function useReveal() {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { el.classList.add("vis"); obs.unobserve(el); }
    }, { threshold: 0.15 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

// ── Components ────────────────────────────────────────────────────────────────
function Navbar({ scrolled }) {
  const [open, setOpen] = useState(false);
  return (
    <nav className={`nav${scrolled ? " scrolled" : ""}`}>
      <a href="#hero" className="nav-logo">elementum</a>
      <ul className={`nav-links${open ? " open" : ""}`}>
        {["About","Work","Services","Testimonials","Contact"].map((l, i) => (
          <li key={l}><a href={`#${["about","progress","services","testimonials","newsletter"][i]}`} onClick={() => setOpen(false)}>{l}</a></li>
        ))}
      </ul>
      <a href="#newsletter" className="nav-cta">Get Started</a>
      <button className="hamburger" onClick={() => setOpen(o => !o)} aria-label="Menu">
        <span/><span/><span/>
      </button>
    </nav>
  );
}

function Hero() {
  return (
    <section className="hero" id="hero">
      <div className="shape-purple"/>
      <div className="shape-circle"/>
      <div className="hero-tag">✦ We are a team of thinkers</div>
      <h1 className="hero-h1">
        The thinkers and<br/>
        doers were <span className="pink">changing</span><br/>
        the <span className="udash">status</span> Quo with <span className="purple">✦</span>
      </h1>
      <p className="hero-sub">
        We are a team of strategic, plugged‑in communicators, researchers. Together,
        we strive first proposes only happens when you know things right.
      </p>
      <div className="avatars">
        {avLabels.map((label, i) => (
          <div key={label} className="av" style={{ background: avColors[i] }}>{label}</div>
        ))}
        <div className="av-stats"><strong>500+</strong>Happy clients</div>
      </div>
    </section>
  );
}

function About() {
  const r1 = useReveal(), r2 = useReveal();
  return (
    <section className="about" id="about">
      <div ref={r1} className="reveal">
        <div className="sec-label">About Us</div>
        <h2 className="about-h2">Tomorrow should<br/>be <span className="pink">better</span> than today</h2>
        <p className="about-p">We are a team of strategic, plugged‑in communicators, researchers. Together, we make first progress only happens when you know things right.</p>
        <p className="about-p">Our approach combines deep industry knowledge with creative thinking to deliver solutions that move the needle—today and well into the future.</p>
        <a href="#progress" className="readmore">Read more →</a>
      </div>
      <div ref={r2} className="reveal img-wrap">
        <div className="img-circle">
          <div className="photo-bg pb1" style={{height:"100%"}}>🤝</div>
        </div>
        <div className="badge"><span>12+</span>Years Experience</div>
        <div className="tri-deco"/>
      </div>
    </section>
  );
}

function Progress() {
  const r1 = useReveal(), r2 = useReveal();
  return (
    <section className="progress-sec" id="progress">
      <div ref={r1} className="reveal progress-img-wrap">
        <div className="img-rect">
          <div className="photo-bg pb2" style={{height:"100%", fontSize:"4rem"}}>💼</div>
        </div>
        <div className="tri-top"/>
      </div>
      <div ref={r2} className="reveal">
        <div className="sec-label">Our Process</div>
        <h2 className="prog-h2">See how we can<br/>help you <span className="pink">progress</span></h2>
        <p className="prog-p">We add a layer of fearless insights and action that drives change. Elementum is committed that progress comes first as we love to design strategy and build for tomorrow.</p>
        <a href="#services" className="readmore">Read more →</a>
      </div>
    </section>
  );
}

const services = [
  { col: "left", cat: "Office of multiple strategic content", items: ["Collaborative & partnership","We talk about our weight","Piloting digital confidence"] },
  { col: "right", cat: "Data-based digital social", items: ["Strategic brand positioning","Research & insights driven growth","Content strategy & execution"] },
];

function Services() {
  const rh = useReveal(), rg = useReveal();
  return (
    <section id="services">
      <div ref={rh} className="reveal services-head">
        <h2 className="srv-h2">What we can<br/><span className="pink">offer</span> you!</h2>
        <p className="srv-intro">From strategic consulting to digital transformation, we bring the full spectrum of expertise to help you grow.</p>
      </div>
      <div ref={rg} className="reveal srv-grid">
        {services.map(({col, cat, items}) => (
          <div key={col} className={col === "left" ? "srv-left" : "srv-right"}>
            <div className="srv-cat">{cat}</div>
            {items.map(name => (
              <div key={name} className="srv-item">
                <span className="srv-name">{name}</span>
                <div className="srv-arrow"><ArrowIcon/></div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  const [active, setActive] = useState(0);
  const r = useReveal();
  const leftAvs  = [0,2,4];
  const rightAvs = [3,5,7];
  return (
    <section className="testi" id="testimonials">
      <div className="sec-label">Testimonials</div>
      <h2 className="testi-h2">What our customer<br/>says <span className="pink">About Us</span></h2>
      <p className="testi-sub">Hear from those who've worked with us</p>
      <div ref={r} className="reveal testi-layout">
        <div className="side-avs">
          {leftAvs.map(i => (
            <div key={i} className="s-av" style={{background: avColors[i]}}>{avLabels[i]}</div>
          ))}
        </div>
        <div className="testi-card">
          <div className="quote">"</div>
          <p className="testi-txt">Elementum delivered the site with little fanfare as they requested. The client found a 50% increase in online visibility within 6 months. Elementum also had an impressive ability to use technologies that the company hadn't used, which proved to be easy to use and reliable.</p>
          <div className="testi-author">
            <div className="auth-av" style={{background: avColors[1]}}>SR</div>
            <div>
              <div className="auth-name">Sarah Richardson</div>
              <div className="auth-role">CEO, TechVentures</div>
            </div>
          </div>
        </div>
        <div className="side-avs">
          {rightAvs.map(i => (
            <div key={i} className="s-av" style={{background: avColors[i]}}>{avLabels[i]}</div>
          ))}
        </div>
      </div>
      <div className="dots">
        {[0,1,2].map(i => (
          <button key={i} className={`dot${active===i?" active":""}`} onClick={() => setActive(i)}/>
        ))}
      </div>
    </section>
  );
}

function Newsletter() {
  const [email, setEmail] = useState("");
  const [success, setSuccess] = useState(false);
  const handleSub = () => {
    if (email.includes("@")) {
      setSuccess(true);
      setTimeout(() => { setSuccess(false); setEmail(""); }, 3000);
    } else {
      alert("Please enter a valid email address.");
    }
  };
  return (
    <section className="newsletter" id="newsletter">
      <div className="sec-label">Stay Connected</div>
      <h2 className="nl-h2">Subscribe to<br/>our newsletter</h2>
      <p className="nl-p">To make sure you are always up to date with the latest news</p>
      <div className="nl-form">
        <input className="nl-input" type="email" placeholder="Enter your email address" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key==="Enter" && handleSub()} />
        <button className={`nl-btn${success?" success":""}`} onClick={handleSub}>
          {success ? "✓ Subscribed!" : "Subscribe Now"}
        </button>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer>
      <div className="footer-grid">
        <div className="fc">
          <div className="brand">elementum</div>
          <p className="brand-sub">Building tomorrow's<br/>solutions today.<br/><br/>Where thinkers meet doers.</p>
        </div>
        <div className="fc">
          <h4>Company</h4>
          <ul>{["Home","About Us","Services","Career","Blog","Awards"].map(l=><li key={l}><a href="#">{l}</a></li>)}</ul>
        </div>
        <div className="fc">
          <h4>Terms &amp; Policies</h4>
          <ul>{["Privacy Policy","Cookie Policy","Terms of Use","Accessibility"].map(l=><li key={l}><a href="#">{l}</a></li>)}</ul>
          <br/>
          <h4>Follow Us</h4>
          <ul>{["Instagram","LinkedIn","Twitter / X","YouTube"].map(l=><li key={l}><a href="#">{l}</a></li>)}</ul>
        </div>
        <div className="fc fc-contact">
          <h4>Contact</h4>
          <p><strong>Office Address</strong><br/>45 Design Street,<br/>New York, NY 10001<br/>United States<br/><br/><strong>Phone &amp; Mail</strong><br/>+1 (555) 000-0000<br/>hello@elementum.com</p>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2025 Elementum. All rights reserved.</span>
        <a href="#">Privacy Policy</a>
      </div>
    </footer>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    // Inject global CSS
    const style = document.createElement("style");
    style.textContent = globalCSS;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <Navbar scrolled={scrolled} />
      <Hero />
      <About />
      <Progress />
      <Services />
      <Testimonials />
      <Newsletter />
      <Footer />
    </>
  );
}
